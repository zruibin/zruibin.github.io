#! /usr/bin/python3
# coding=utf-8
# 
# Template.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/14.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import Macros

HTML_META_SEO = """<meta name="keywords" content="Ruibin.Chow,zruibin,ruibin,RBCHOW" />
<meta name="description" content="Ruibin.Chow - 无论你是狮子还是羚羊,你都必须奔跑,无论你是贫穷还是富有,你都必须奋斗！" />
<meta name="COPYRIGHT" content="版权所有2010,""" + Macros.HOST_NAME + """\" />
"""

HTML_META_SEO_DATA = """<meta name="keywords" content="%s,Ruibin.Chow,zruibin,ruibin,RBCHOW" />
<meta name="description" content="%s" />
<meta name="COPYRIGHT" content="版权所有2010,""" + Macros.HOST_NAME + """\" />
"""

HTML_META = """
<link rel="shortcut icon" href="../vender/image/me.png" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
""" + HTML_META_SEO

HTML_COPYRIGHT = """
<!-- CopyRight BEGIN -->
<div id="copyright" ></div>
<!-- CopyRight END -->
"""


""" 分享代码 """
HTML_SHARE = """
<!-- Share BEGIN -->
<div id="share"></div>
<!-- Share END -->
"""

""" 评论代码 """
HTML_COMMENT = """
<!-- 评论 start -->
<div id="comment"></div>
<!-- 评论 end -->
"""

HTML_LINK = """

"""

HTML_SCRIPT = """
<script type="text/javascript" charset="UTF-8">
var sourcePrefix = "../";
</script>
<script type="text/javascript" charset="UTF-8" src="../vender/js/seajs/sea.js"></script>
<script type="text/javascript" charset="UTF-8" src="../vender/js/seajs/seajs-css.js"></script>
"""

# ------------------------------------------------------------------------------------------------------------------------------------------------------------------------



""" 文章详细内容代码 """
ARTICLE_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head> 
<title>${title} - Ruibin.Chow</title>

""" + HTML_META + HTML_SCRIPT + """
</head>

<body style="visibility: hidden;">

${navBar}

<div class="container" id="content">

<div id='header'>
    <h2>${title}</h2>
    <footer>
        Date:<span id='create_time'>
            ${createTime}
        </span>
        &nbsp;
        Tags: ${tags}
    </footer>
    <hr/>
</div>

${content}

<br/>
<br/>
<p></p>

""" + HTML_SHARE + """

<br/>

""" + HTML_COMMENT + HTML_COPYRIGHT + """

</body>

<script>
var sourceFile = "${source}";
</script>

<script charset="UTF-8" src="../vender/js/loaded.js"></script>

</html>
"""



""" 文章列表代码 """
ARTICLE_HTML_INDEX_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<title>${title} - Ruibin.Chow</title>

""" + HTML_META + HTML_SCRIPT + """
</head>

<body style="visibility: hidden;">

${navBar}

<div class="container" id="list_content">
      ${div}
</div>

${indexSize}

<br/>

""" + HTML_COPYRIGHT + """
</body>

<script charset="UTF-8" src="../vender/js/loaded.js"></script>

</html>
"""



ARTICLE_HTML_INDEX_ARTICLE_TEMPLATE = """
<article>
<h2><a href="%s">%s</a></h2>
<div class="summary">
    <p>%s</p>
    <a class="more" href="%s">more...</a>
</div>
</article>
<hr/>
"""



""" 标签页内容代码 """
TAGS_HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<title>所有标签 - Ruibin.Chow</title>

""" + HTML_META + HTML_SCRIPT + """
</head>

<body style="visibility: hidden;">

%s

<div class="container" id="content">

    <div class="tag-cloud">
        <div class="tag-cloud-title">
        
            %s Tags In Total
        
        </div>

        <div class="tag-cloud-tags">
            %s
        </div>

    </div>

</div>

""" + HTML_COPYRIGHT + """
</body>

<script charset="UTF-8" src="../vender/js/loaded.js"></script>

</html>
"""


""" 导航栏样式模板 """
HTML_NAVBAR_TEMPLATE = """
<div id="navbar" >
    <div id="menu" class="container">
    <ul>
    <!-- <li><a href="#" class="item">Ruibin.Chow</a></li> -->
    <li><a href="../about.html" class="item">About Me</a></li>
    <li><a href="./index.html" class="item">Blog</a></li>
    <li><a class="item" href="../article/tags.html">Tags</a>
        &nbsp;
        <div class="subs" id="tags"></div> 
    </li>
    <li><a href="./""" + Macros.ARCHIVES + """.html" class="item">Archives</a></li>

    </ul>
    </div>
</div> 
<p></p>
"""









