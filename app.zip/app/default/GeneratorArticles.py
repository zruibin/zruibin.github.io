#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorArticles.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import Macros, Util, DBManager
import os, os.path, shutil, base64
import default.Template as Template
import default.GeneratorChoice as GeneratorChoice
import default.GeneratorTags as GeneratorTags
import default.GeneratorRSS as GeneratorRSS
from string import Template as TPL
from RBLog import *
import Global


def generateArticleImages(DIR):
    """生成所有文章的图片"""
    oldDir =  Macros.MARDDOWN_DIR + Macros.ARTICLE_IMAGES_DIR_NAME
    newDir = Macros.ARTICLE_DIR  + '/' + Macros.ARTICLE_IMAGES_DIR_NAME
    if os.path.exists(oldDir):
        shutil.copytree(oldDir, newDir)
    pass

def generateArticleContent(DIR, article):
    """获得文章内容，分从数据库中取或直接读取文件内容文本"""
    content = ''
    if Macros.IS_BACKUP_ARTICLE_CONTENT:
        content = base64.decodestring(article[8])
    else:
        articleName = article[1]
        articleName = Util.str_strip(articleName)
        content = Util.getTheFileContent(Macros.MARDDOWN_DIR + articleName)

    # 去掉头部文件信息
    content = Util.substring(Macros.MARKDOWN_DATA_TITLE_END, content)
    # 将markdown文本转换html的样式
    content  = Util.transformTheMarkdownToHtml(content)
    return content


def generateArticleToHtml(DIR, article):
    """通过信息生成每一篇文章"""
    DIR = Util.str_strip(DIR)
    # os.path.basename(DIR)

    dbDao = DBManager.DBDao.getinstance()
    articleTags = dbDao.queryArticleAllTagsByAtricleId(article[0])

    createTime = '%s' % article[6]
    createTime = Util.convertTimeStampToDate(createTime)
    modifiyTime = '%s' % article[7]

    tags = GeneratorTags.generateArticleTags(articleTags, DIR)
            
    articleName = article[1]
    articleName = Util.str_strip(articleName)
    
    pinyin = Util.substringTheFileName(article[5])
    htmlName = DIR + '/' + pinyin + '.'+ Macros.POSTFIX
    hrefName = Macros.HOST_NAME + '/' + os.path.basename(Macros.ARTICLE_DIR) + '/' + pinyin + '.'+ Macros.POSTFIX
    LogI(articleName)

    title = articleName[:-3]

    content = generateArticleContent(DIR, article)

    # ----------------------------------------------------------------------------------------
    globalContent = str(content)
    globalContentDict = {"title": title, 
                            "navBar": "",
                            "createTime": createTime,
                            "tags": "、".join(articleTags),
                            "content": globalContent,
                            "source": articleName
                        }
    globalContentTpl = TPL(Template.ARTICLE_HTML_TEMPLATE)
    globalContent = globalContentTpl.substitute(globalContentDict)
    # 存放全局有序字典
    Global.globalArticleDict[pinyin] = {
        "title": title,
        "content": globalContent
    }
    # ----------------------------------------------------------------------------------------

    contentDict = {"title": title, 
                                "navBar": Template.HTML_NAVBAR_TEMPLATE,
                                "createTime": createTime,
                                "tags": tags,
                                "content": content,
                                "source": articleName
                            }
    # content = Template.ARTICLE_HTML_TEMPLATE % (title, Template.HTML_NAVBAR_TEMPLATE, title, createTime, tags, content)
    contentTpl = TPL(Template.ARTICLE_HTML_TEMPLATE)
    content = contentTpl.substitute(contentDict)

    # 网站SEO优化
    keywords = title + ',' + ",".join(articleTags)
    seo_data = Template.HTML_META_SEO_DATA % (keywords, article[4])
    content = Util.convert_character(content, Template.HTML_META_SEO, seo_data)

    content = Util.convert_character(content, "./image", "../file/image")
    content = Util.convert_character(content, "./zip", "../file/zip")
    content = Util.convert_character(content, '<img src="', '<img src="../vender/image/img_loading.gif" data-src="')
    content = Util.convert_character(content, '.webp"', '.png"')
    Util.writeContentToFile(htmlName, content)
    # LogI(htmlName)

    pass


def generateAllArticleToHtml(DIR):
    """通过数据库信息生成所有文章"""
    DIR = Util.str_strip(DIR)
    if os.path.exists(DIR):
        shutil.rmtree(DIR) # 空目录、有内容的目录都可以删
    if not os.path.exists(DIR):
        os.mkdir(DIR)

    dbDao = DBManager.DBDao.getinstance()
    articleArray = dbDao.queryArticles()

    # 分页，每页Macros.SIZE_OF_PAGES篇文章
    articleSize = len(articleArray)
    pageSize = int(articleSize/Macros.SIZE_OF_PAGES) if (articleSize%Macros.SIZE_OF_PAGES == 0) else (int(articleSize/Macros.SIZE_OF_PAGES) + 1)

    if articleSize <= Macros.SIZE_OF_PAGES:
        pageSize = 1

    for i in range(1, pageSize+1):
        start = (i-1) * Macros.SIZE_OF_PAGES
        end = start + Macros.SIZE_OF_PAGES
        if i == pageSize:
            size = Macros.SIZE_OF_PAGES if (articleSize%Macros.SIZE_OF_PAGES == 0)  else (articleSize%Macros.SIZE_OF_PAGES)
            end = start + size

        tempArticleArray = articleArray[start:end] 

        DIV = ''
        for article in tempArticleArray:
            name = article[1][:-3]
            # name = name if len(name) < 30 else (name[:30] + '...')
            pinyin = Util.substringTheFileName(article[5])
            href = pinyin + '.'+ Macros.POSTFIX
            summary = article[4]
            DIV = DIV + (Template.ARTICLE_HTML_INDEX_ARTICLE_TEMPLATE % (href, name, summary, href))
            generateArticleToHtml(DIR, article)

        indexName = DIR + '/' + Macros.PAGE + '_' + str(i) + '.'+ Macros.POSTFIX
        indexSize = GeneratorChoice.generatorIndexChoice(pageSize, i, len(articleArray), Macros.PAGE)

        contentDict = {"title": "我的文章", 
                                "navBar": Template.HTML_NAVBAR_TEMPLATE,
                                "div": DIV,
                                "indexSize": indexSize
                            }
        contentTpl = TPL(Template.ARTICLE_HTML_INDEX_TEMPLATE)
        content = contentTpl.substitute(contentDict)
        Util.writeContentToFile(indexName, content)

    #index.html页面，等同于page_1.html
    Util.writeContentToFile(DIR + '/' + Macros.INDEX_NAME, Util.getTheFileContent(DIR + '/' + 'page_1.html'))
    #复制图片
    # generateArticleImages(DIR)
    # 生成RSS
    # GeneratorRSS.generateRSSXml(DIR, articleArray)
    pass


if __name__ == '__main__':
    generateAllArticleToHtml(Macros.ARTICLE_DIR)
    pass
