#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorAboutMe.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import os.path
import Macros, Util, DBManager
import default.Template as Template

from RBLog import *


HTML_ABOUT_ME_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
 <head>   
<title>关于我 - Ruibin.Chow</title>

""" + Template.HTML_META + Template.HTML_SCRIPT + """
</head>

<body style="visibility: hidden;">

%s

<br><br><p></p>
<br><br><p></p>

<div class='container'>

%s

</div>

<br>

""" + Template.HTML_LINK + Template.HTML_COPYRIGHT + """

</body>

<script charset="UTF-8" src="../vender/js/loaded.js"></script>

</html>

"""


def generateTheAboutMeHtml():
    """ 生成个人信息页面"""
    dbDao = DBManager.DBDao.getinstance()
    articleArray = dbDao.queryArticles()

    abountMe = Util.getTheFileContent(Macros.ABOUTME_DIR + "about.md")
    # 将markdown文本转换html的样式
    abountMe  = Util.transformTheMarkdownToHtml(abountMe)

    indexName = '../' + 'about.html'
    indexSize = '' #Template.ARTICLE_HTML_INDEX_SIZE_TEMPLATE % len(articleArray)
    articleDir = os.path.basename(Macros.ARTICLE_DIR)
    content = HTML_ABOUT_ME_TEMPLATE % (Template.HTML_NAVBAR_TEMPLATE, abountMe)
    content = Util.convert_character(content, '/index.html', './' + articleDir + '/index.html')
    content = Util.convert_character(content, '/' + Macros.ARCHIVES +'.html', './' + articleDir + '/' + Macros.ARCHIVES +'.html')
    content = Util.convert_character(content, '/' + Macros.TAG_PREFIX, './' + articleDir + '/'+ Macros.TAG_PREFIX)
    content = Util.convert_character(content, '../', './')
    Util.writeContentToFile(indexName, content)
    LogI("About Me")
    pass


