#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorChoice.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import Macros, Util, DBManager

 
ARTICLE_HTML_INDEX_SELECTOR_TEMPLATE = """
 <li>&nbsp;&nbsp;<select id='pageSelector' onchange="selectorOnChange(this.value)" >
 %s
</select></li>
"""

ARTICLE_HTML_INDEX_SIZE_TEMPLATE = """
<div id="pagelist" class="pagelist">
 <!-- <span> %s条数据  共%s页</span>  -->
 <ul>
 %s
 </ui>
</div>
""" 


def  generatorIndexName(pagePrefix, index):
    """ 生成索引名称
    pagePrefix: 前缀
    index: 当前的位置
    """
    indexName = pagePrefix + '_' + str(index) + '.'+ Macros.POSTFIX
    return indexName


def generatorIndexHref(pageSize, currentIndex, pagePrefix, isUp=True):
    href = ''
    disable = False
    if currentIndex == 1 and isUp:
        disable = True
    if currentIndex == pageSize and isUp == False:
        disable = True

    if isUp:
        upHref = '<li><a %s>«</a></li>' % ('href="'+generatorIndexName(pagePrefix, currentIndex-1)+'"' if disable == False else '')
        href = upHref
    else:
        downHref = '<li><a %s>»</a></li>' % ('href="'+generatorIndexName(pagePrefix, currentIndex+1)+'"' if disable == False else '')
        href = downHref
    
    return href


def generatorIndexChoice(pageCount, currentIndex, count, pagePrefix, manyOfPages=Macros.SIZE_OF_PAGES):
    """ 生成页面索引html
    pageCount: 生成多少页
    currentIndex: 当前的位置
    count: 总共有多少条
    pagePrefix: 前缀
    manyOfPages: 每页有多少条
    """
    pageHref = ''

    for x in range(1, pageCount+1):
        indexHref = generatorIndexName(pagePrefix, x)
        if x == currentIndex:
            # pageHref = pageHref + '<a href="%s" id="current_list_hlt">%d</a>' % (generatorIndexName(pagePrefix, x), x)
            pageHref = pageHref + '<option value="%s" selected = "selected">第%d页</option>' % (indexHref, x)
        else:
            # pageHref = pageHref + '<a href="%s">%d</a>' % (generatorIndexName(pagePrefix, x), x)
            pageHref = pageHref + '<option value="%s">第%d页</option>' % (indexHref, x)
    pageHref = ARTICLE_HTML_INDEX_SELECTOR_TEMPLATE % pageHref

    pageHref = generatorIndexHref(pageCount, currentIndex, pagePrefix, True) + generatorIndexHref(pageCount, currentIndex, pagePrefix, False) + pageHref

    indexSize = ARTICLE_HTML_INDEX_SIZE_TEMPLATE % (count, pageCount, pageHref)

    if count <= manyOfPages:
        indexSize = ''

    return indexSize


if __name__ == '__main__':
    print(generatorIndexChoice(12, 3, 22, 'page'))
    pass



