#! /usr/bin/python3
# coding=utf-8
# 
# Generator.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/13.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import Macros, Util
import os, os.path, shutil

import default.GeneratorTags as GeneratorTags
import default.GeneratorArchives as GeneratorArchives
import default.GeneratorIndex as GeneratorIndex
import default.GeneratorAboutMe as GeneratorAboutMe
import default.GeneratorArticles as GeneratorArticles


def generateDateToMarkdown(fileName):
    """为markdown文件添加日期隐藏头"""
    fileName = Util.str_strip(fileName)
    createTime = Util.getTheFileCreateTime(fileName)
    modifiedTime = Util.getTheFileLastModifiedTime(fileName)

    allText = Util.getTheFileContent(fileName)

    title = Macros.MARKDOWN_DATA_TITLE % (createTime, modifiedTime)
    allText = title + '\n' + allText
    Util.writeContentToFile(fileName, allText)

    pass


def generateAllArticleToHtml(DIR):
    """通过数据库信息生成所有文章"""
    GeneratorArticles.generateAllArticleToHtml(DIR)
    pass


def generateAllTagsToHtml(DIR):
    """生成所有的标签页"""
    GeneratorTags.generateAllTagsToHtml(DIR)
    pass


def generateArchivesToHtml(DIR):
    """生成归档页"""
    GeneratorArchives.generateArchivesToHtml(DIR)
    pass


def generateTheIndexHtml():
    """ 生成根目录下的index.html，前提article下必须有index.html"""
    GeneratorIndex.generateTheIndexHtml()
    pass


def generateTheAboutMeHtml():
    """ 生成个人信息页面"""
    GeneratorAboutMe.generateTheAboutMeHtml()
    pass


if __name__ == '__main__':
    
    # print Macros.MARKDOWN_VENDER_CSS_DIR
    
    # generateAllMarkdownToDB(Macros.MARDDOWN_DIR)
    # generateAllArticleToHtml(Macros.ARTICLE_DIR)
    # generateAllTagsToHtml(Macros.ARTICLE_DIR)
    # generateArchivesToHtml(Macros.ARTICLE_DIR)
    # generateTheIndexHtml()

    pass












