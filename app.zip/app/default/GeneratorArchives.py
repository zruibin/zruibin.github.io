#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorArchives.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#


import Macros, Util, DBManager
import default.Template as Template
import default.GeneratorChoice as GeneratorChoice
from RBLog import *

ARTICLE_HTML_ARCHIVES_TEMPLATE = """
<!DOCTYPE html>
<html lang="zh-CN">
<head> 
<title>Archives - Ruibin.Chow</title>

""" + Template.HTML_META + Template.HTML_SCRIPT + """

</head>

<body style="visibility: hidden;">

%s

<br>



<div class="times">
%s
<ul>

%s
<li><span></span></li>

</ul>
</div>

%s

<p></p><br>

""" + Template.HTML_LINK + Template.HTML_COPYRIGHT + """

<br>
</body>

<script charset="UTF-8" src="../vender/js/loaded.js"></script>

</html>
"""


ARTICLE_HTML_ARCHIVES_LI_TEMPLATE ="""
<li><b></b><span>%s</span><p><a href="%s">%s</a></p><hr class='archives_hr'></li>
"""



def generateArchivesToHtml(DIR):
    """生成归档页"""
    dbDao = DBManager.DBDao.getinstance()
    articleArray = dbDao.queryArticlesDefault()


    articleSize = len(articleArray)
    pageSize = 1
    if articleSize > Macros.SIZE_OF_ARCHIVES:
        pageSize = int(articleSize/Macros.SIZE_OF_ARCHIVES) if (articleSize%Macros.SIZE_OF_ARCHIVES == 0) else (int(articleSize/Macros.SIZE_OF_ARCHIVES) + 1)

    for i in range(1, pageSize+1):
        start = (i-1) * Macros.SIZE_OF_ARCHIVES
        end = start + Macros.SIZE_OF_ARCHIVES
        if i == pageSize:
            size = Macros.SIZE_OF_ARCHIVES if (articleSize%Macros.SIZE_OF_ARCHIVES == 0)  else (articleSize%Macros.SIZE_OF_ARCHIVES)
            end = start + size

        tempArticleArray = articleArray[start:end]

        LI = ''
        for article in tempArticleArray:
            name = article[1][:-3]
            # name = name if len(name) < 30 else (name[:30] + '...')
            pinyin = Util.substringTheFileName(article[5])
            href = pinyin + '.'+ Macros.POSTFIX
            summary = article[4]
            time = Util.convertTimeStampToDate(article[6])
            LI = LI + (ARTICLE_HTML_ARCHIVES_LI_TEMPLATE % (time, href, name))

        indexName = DIR + '/' + Macros.ARCHIVES + '.'+ Macros.POSTFIX if i == 1 else DIR + '/' + Macros.ARCHIVES + '_' + str(i) + '.'+ Macros.POSTFIX
        articleSizeTitle = """<span id='articleSize'><strong>共""" + str(len(articleArray)) + """篇文章</strong></span>"""

        pageIndexHref = GeneratorChoice.generatorIndexChoice(pageSize, i, len(articleArray), Macros.ARCHIVES, Macros.SIZE_OF_ARCHIVES)
        pageIndexHref = Util.convert_character(pageIndexHref, Macros.ARCHIVES+'_1', Macros.ARCHIVES)

        content = ARTICLE_HTML_ARCHIVES_TEMPLATE % (Template.HTML_NAVBAR_TEMPLATE, articleSizeTitle, LI, pageIndexHref)
        Util.writeContentToFile(indexName, content)
        LogI(Macros.ARCHIVES + '_' + str(i))

    pass