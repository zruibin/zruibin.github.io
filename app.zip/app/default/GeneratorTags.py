#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorTags.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import sys
from string import Template as TPL

import DBManager, Macros, Util
import default.Template as Template
from RBLog import *


TAG_CACHE_LIST = []

def generateTagToHtml(DIR, existsTags):
    """生成每一个标签页"""
    dbDao = DBManager.DBDao.getinstance()
    global TAG_CACHE_LIST
    for tagKey in existsTags:
        tagValue = str(tagKey)
        tagValuePinyin = Util.convertChineseToPinyin(tagValue)
        articleArray = dbDao.queryAllArticleByTagId(tagKey)

        DIV = ''
        for article in articleArray:
            name = article[1][:-3]
            # name = name if len(name) < 30 else (name[:30] + '...')
            pinyin = Util.substringTheFileName(article[5])
            href = pinyin + '.'+ Macros.POSTFIX
            summary = article[4]
            DIV = DIV + (Template.ARTICLE_HTML_INDEX_ARTICLE_TEMPLATE % (href, name, summary, href))

        tagValuePinyin = Util.convert_character(tagValuePinyin, '/', '') # 由于目录中不能带有/，所以将所有的/删除掉
        tagName = DIR + "/" + Macros.TAG_PREFIX + tagValuePinyin + '.'+ Macros.POSTFIX
        LogI(tagName)
        tagSize = ''#Template.ARTICLE_HTML_INDEX_SIZE_TEMPLATE % (len(articleArray), len(articleArray)/10)

        contentDict = {"title": tagValue, 
                                "navBar": Template.HTML_NAVBAR_TEMPLATE,
                                "div": DIV,
                                "indexSize": tagSize
                            }
        contentTpl = TPL(Template.ARTICLE_HTML_INDEX_TEMPLATE)
        content = contentTpl.substitute(contentDict)
        # content =  Template.ARTICLE_HTML_INDEX_TEMPLATE % (tagValue, Template.HTML_NAVBAR_TEMPLATE, DIV, tagSize)

        Util.writeContentToFile(tagName, content)

        tagDict = {
            "name": tagValue,
            "path": tagName,
            "count": str(len(articleArray))
        }
        TAG_CACHE_LIST.append(tagDict)
        pass
    pass


def generateTagsHtml(DIR):
    """
    生成所有标签的页面
    """
    tagsFileName = DIR + "/tags" + '.'+ Macros.POSTFIX
    content = ""
    global TAG_CACHE_LIST
    for tagDict in TAG_CACHE_LIST:
        tagString = """
            <a href="%s">%s<span class="tag-count">%s</span></a>
        """ % (tagDict["path"], tagDict["name"], tagDict["count"])
        content = content + tagString
        pass
    html = (Template.TAGS_HTML_TEMPLATE % (Template.HTML_NAVBAR_TEMPLATE, 
                                            str(len(TAG_CACHE_LIST)), content))
    Util.writeContentToFile(tagsFileName, html)
    pass
    

def generateAllTagsToHtml(DIR):
    """生成所有的标签页"""
    dbDao = DBManager.DBDao.getinstance()
    existsTags = dbDao.queryAllExistTags()

    generateTagToHtml(DIR, existsTags)
    generateTagsHtml(DIR)
    pass



ARTICLE_HTML_TAGS_TEMPLATE = """
<span id='article_tags'>
        %s
</span>
"""

ARTICLE_HTML_TAG_TEMPLATE = """
<a href='%s' class='article_tag'>%s</a>
"""

def generateArticleTags(articleTags, DIR):
    """"生成每篇文章所拥有的标签"""
    tags = ' '
    if len(articleTags) > 0:
        for tag in articleTags:
            tagValuePinyin = Util.convertChineseToPinyin(tag)
            tagValuePinyin = Util.convert_character(tagValuePinyin, '/', '') # 由于目录中不能带有/，所以将所有的/删除掉
            tagHref = DIR + "/" + Macros.TAG_PREFIX + tagValuePinyin + '.'+ Macros.POSTFIX
            tags = tags + (ARTICLE_HTML_TAG_TEMPLATE % (tagHref, tag))
        tags = ARTICLE_HTML_TAGS_TEMPLATE % tags

    return tags
    pass




if __name__ == '__main__':
    print(generateArticleTags(["11", "22"], '../tat'))
    pass
