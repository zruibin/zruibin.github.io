#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorIndex.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import os.path
import Macros, Util


def generateTheIndexHtml():
    """ 生成根目录下的index.html，前提article下必须有index.html"""
    indexName = '../' + Macros.INDEX_NAME
    articleDir = os.path.basename(Macros.ARTICLE_DIR)
    content = Util.getTheFileContent(Macros.ARTICLE_DIR + '/' + Macros.INDEX_NAME)
    content = Util.convert_character(content, '/index.html', './' + articleDir + '/index.html')
    content = Util.convert_character(content, "/" + Macros.ARCHIVES + '.html', './' + articleDir + "/" + Macros.ARCHIVES + '.html')
    content = Util.convert_character(content, '<h2><a href="', '<h2><a href="' + './' + articleDir + '/')
    content = Util.convert_character(content, '<a class="more" href="', '<a class="more" href="./article/')
    content = Util.convert_character(content, '/' + Macros.TAG_PREFIX, './' + articleDir + '/' + Macros.TAG_PREFIX)
    content = Util.convert_character(content, 'page_', './' + articleDir + '/page_')
    content = Util.convert_character(content, '../', './')
    Util.writeContentToFile(indexName, content)

    pass