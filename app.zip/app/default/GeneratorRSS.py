#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorRSS.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/06/13.
# Copyright (c) 2016年 Ruibin.Chow All rights reserved.
#

import time, os, base64
import Util, Macros, DBManager
import default.GeneratorTags
import default.GeneratorArticles
from RBLog import *


RSS_XML_TEMPLATE = """<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>Ruibin.Chow</title>
  <subtitle>无论你是狮子还是羚羊,你都必须奔跑,无论你是贫穷还是富有,你都必须奋斗！</subtitle>
  <link href="./atom.xml" rel="self"/>
  
  <link href=\"""" + Macros.HOST_NAME +"""\"/>
  <updated>%s</updated>
  <id>""" + Macros.HOST_NAME + """</id>
  
  <author><name>Ruibin.Chow</name></author>
  
  <generator uri=\"""" + Macros.HOST_NAME +"""\">Ruibin.Chow</generator>
    %s

</feed>
"""

RSS_XML_ENTRY_TEMPLATE = """ 

  <entry>
    <title>%s</title>
    <link href="%s"/>
    <id>%s</id>
    <published>%s</published>
    <updated>%s</updated>

    <content type="html">
      %s
    </content>
        
    <summary type="html">
      %s
    </summary>
        %s
  </entry>
"""

RSS_XML_ENTRY_CATEGORY_TEMPLATE = """<category term="%s" scheme="%s"/>"""



def generateRSSEntry(DIR, article):
    rss_entry_string = '\n    ' + RSS_XML_ENTRY_TEMPLATE

    dbDao = DBManager.DBDao.getinstance()
    articleTags = dbDao.queryArticleAllTagsByAtricleId(article[0])

    createTime = '%s' % article[6]
    createTime = Util.convertTimeStampToDate(createTime)
    modifiyTime = '%s' % article[7]
    modifiyTime = Util.convertTimeStampToDate(modifiyTime)

    tags_string = ''
    for tag in articleTags:
        tagValuePinyin = Util.convertChineseToPinyin(tag)
        tagValuePinyin = Util.convert_character(tagValuePinyin, '/', '') # 由于目录中不能带有/，所以将所有的/删除掉
        tagHref = Macros.HOST_NAME + "/article" + "/" + Macros.TAG_PREFIX + tagValuePinyin + '.'+ Macros.POSTFIX
        tags_string = tags_string + '\n    ' + (RSS_XML_ENTRY_CATEGORY_TEMPLATE % (tag, tagHref))
        # print tag, tagHref

    articleName = article[1][:-3]
    articleName = Util.str_strip(articleName)    
    pinyin = Util.substringTheFileName(article[5])
    htmlName = DIR + '/' + pinyin + '.'+ Macros.POSTFIX
    hrefName = Macros.HOST_NAME + "/" + os.path.basename(Macros.ARTICLE_DIR) + '/' + pinyin + '.'+ Macros.POSTFIX
    summary = article[4]

    #获取文章内容
    content  = GeneratorArticles.generateArticleContent(DIR, article)

    content = Util.convert_character(content, './image/', Macros.HOST_NAME + "/article/image/")
    content = Util.convert_character(content, '&nbsp;', '')
    content = Util.convert_character(content, '<', '&lt;')
    content = Util.convert_character(content, '>', '&gt;')
    content = Util.convert_character(content, '\'', '&quot;')
    content = Util.convert_character(content, '"', '&quot;')
    
    rss_entry_string = rss_entry_string % (articleName, hrefName, hrefName, createTime, modifiyTime, content, summary, tags_string)
    return rss_entry_string


def generateRSSXml(DIR, articleArray):

    all_rss_entry_string = ''
    for article in articleArray:
        all_rss_entry_string = all_rss_entry_string + generateRSSEntry(DIR, article)

    rss_xml_content = RSS_XML_TEMPLATE % (Util.convertTimeStampToDate(time.time()), all_rss_entry_string)
    Util.writeContentToFile(DIR+'/atom.xml', rss_xml_content)
    LogI("生成atom.xml")
    pass



if __name__ == '__main__':
    dbDao = DBManager.DBDao.getinstance()
    articleArray = dbDao.queryArticles()
    generateRSSXml(Macros.ARTICLE_DIR, articleArray)
    pass
