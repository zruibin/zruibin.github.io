#! /usr/bin/python3
# coding=utf-8
# 
# GeneratorToDB.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2016/04/16.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import Macros, Util, DBManager
import os, os.path, base64, json
from RBLog import *


def generateMarkdownToDB(fileName, index):
    """将每篇文章的信息入数据库"""
    fileName = Util.str_strip(fileName)
    content = Util.getTheFileContent(fileName)
    html = Util.text_wrap_by(Macros.MARKDOWN_DATA_TITLE_BEGIN, Macros.MARKDOWN_DATA_TITLE_END, content)

    # 是否将文章内容进行base64编码入库
    if Macros.IS_BACKUP_ARTICLE_CONTENT:
        content = base64.encodestring(content) # 对字符串编码
    else:
        content = ''

    datas = json.loads(html)

    #文章名称，即文件名
    baseName = os.path.basename(fileName) 
    # 名称拼音
    pinyin = Util.convert_character(baseName[:-3], ' ', '')
    pinyin = Util.convert_character(pinyin, '、', '')
    pinyin = Util.convertChineseToPinyin(pinyin)
    #是否有置顶
    top = datas[Macros.MARKDOWN_DATA_TOP] if Macros.MARKDOWN_DATA_TOP in datas else '' 
    #是否有概要
    summary = datas[Macros.MARKDOWN_DATA_SUMMARY] if Macros.MARKDOWN_DATA_SUMMARY in datas else '' 

    articleArray = [index, baseName, fileName, top, summary, pinyin, content]

    # 是否有记录创建时间，没有则使用文件的系统创建时间(类Unix下创建时间跟修改时间一致)
    createTime = datas[Macros.MARKDOWN_DATA_CREATE] if Macros.MARKDOWN_DATA_CREATE in datas else Util.getTheFileCreateTime(fileName)
    # 将创建时间转成Unix时间戳
    createTime = Util.convertDateToTimeStamp(createTime) 
    # 是否有记录修改时间，没有则使用文件的系统修改时间
    modifiyTime = datas[Macros.MARKDOWN_DATA_MODIFY] if Macros.MARKDOWN_DATA_MODIFY in datas else Util.getTheFileLastModifiedTime(fileName)
    # 将最后修改时间转成Unix时间戳
    modifiyTime = Util.convertDateToTimeStamp(modifiyTime)
    articleDateArray = [index, createTime, modifiyTime]

    tags = datas[Macros.MARKDOWN_DATA_TAGS] if Macros.MARKDOWN_DATA_TAGS in datas else ''
    tags = tags.split('、')
    # print tags
    LogV(tags)

    dbDao = DBManager.DBDao.getinstance()
    dbDao.insertArticle(articleArray) # 文章入库
    dbDao.insertArticleDate(articleDateArray) #文章信息入库
    # 插入该文章所属的所有标签
    for value in tags:
        tagArray = [value, index]
        dbDao.inserTagArticle(tagArray)
    pass


def generateAllMarkdownToDB(DIR):
    """将markdown目录下所有文章的信息入数据库"""
    DIR = Util.str_strip(DIR)
    if os.path.exists(DBManager.DB_NAME): #是否有数据库，有则先删除(包含数据)
        os.remove(DBManager.DB_NAME)
    
    dbDao = DBManager.DBDao.getinstance()
    dbDao.createTable() #生成表

    array = Util.getAllFileInDirBeyoundTheDir(Macros.MARDDOWN_DIR, Macros.ARTICLE_IMAGES_DIR_NAME)
    index = 0
    for path in array:
        fileName = os.path.basename(path)
        if fileName in Macros.MARKDOWN_DATA_EXCEPT_FILES:
            continue
        generateMarkdownToDB(path, index)
        index = index + 1

    pass



if __name__ == '__main__':
    pass
