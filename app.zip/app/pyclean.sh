#! /bin/sh
#
# pyclean.sh
#
# Created by Ruibin.Chow on 2022/03/27.
# Copyright (c) 2022年 Ruibin.Chow All rights reserved.
#

pyclean () {
    find . -type f -name '*.py[co]' -delete -o -type d -name __pycache__ -delete
}

pyclean

