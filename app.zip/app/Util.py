#! /usr/bin/python3
# coding=utf-8
# 
# Util.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/14.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import Macros
import os.path, time, datetime, re
import urllib, random, shutil, collections

from Pinyin import pinyin
from mistune import mistune
from pygments import highlight
from pygments.lexers import get_lexer_by_name
from pygments.formatters import HtmlFormatter
from RBLog import *
# from ebooklib import epub


def show(DIR):
    """列出指定目录下所有文件"""
    DIR = str_strip(DIR)
    array = getAllFileInDir(DIR)
    for path in array:
        LogI(path)
        basename = os.path.basename(path)
        LogI(basename)
        # print basename.decode('utf-8')


        format = '%Y-%m-%d %H:%M:%S'
        ctime = os.path.getctime(path)#time.ctime(os.path.getctime(name))
        mtime = os.path.getmtime(path)#time.ctime(os.path.getmtime(name))
        # print os.stat(name)
        createdT = datetime.datetime.fromtimestamp(ctime).strftime(format)
        modifiedT = datetime.datetime.fromtimestamp(mtime).strftime(format)

        LogI(("创建时间 : %s(%s), 最后修改时间: %s(%s)" % (createdT, ctime, modifiedT, mtime)))
        LogI(" ")
    pass


def getAllFileInDir(DIR):
    """返回指定目录下所有文件的集合"""
    DIR = str_strip(DIR)
    array = getAllFileInDirBeyoundTheDir(DIR, '')
    return array


def getAllFileInDirBeyoundTheDir(DIR, beyoundDir):
    """返回指定目录下所有文件的集合，beyoundDir的目录不包含"""
    DIR = str_strip(DIR)
    array = []
    # LogI(DIR+beyoundDir)
    for root, dirs, files in os.walk(DIR):
        if len(beyoundDir) != 0 and os.path.exists(DIR+beyoundDir):
            if beyoundDir not in dirs:
                continue
        for name in files:
            path = os.path.join(root,name)
            array.append(path)
            # print path
            # print os.path.basename(name)
    return array


def convertDateToTimeStamp(dateString, format=Macros.TIME_FORMAT):
    """从标准格式转化成时间截"""
    #eg: dateString = "2015-10-13 13:48"
    d = datetime.datetime.strptime(dateString, format)
    time_sec_float = time.mktime(d.timetuple())

    return time_sec_float


def convertTimeStampToDate(timeString, format=Macros.TIME_FORMAT):
    date = datetime.datetime.fromtimestamp(float(timeString)).strftime(format)
    return date


def getTheFileTime(fileName):
    """获得文件的创建与最后修改时间"""
    fileName = str_strip(fileName)
    format = Macros.TIME_FORMAT
    ctime = os.path.getctime(fileName)
    mtime = os.path.getmtime(fileName)

    createdT = datetime.datetime.fromtimestamp(ctime).strftime(format)
    modifiedT = datetime.datetime.fromtimestamp(mtime).strftime(format)

    return [createdT, modifiedT]


def getTheFileCreateTime(fileName):
    """获得文件的创建时间"""
    fileName = str_strip(fileName)
    createdT = getTheFileTime(fileName)[0]
    return createdT


def getTheFileLastModifiedTime(fileName):
    """获得文件的最后修改时间"""
    fileName = str_strip(fileName)
    modifiedT = getTheFileTime(fileName)[1]
    return modifiedT


def getTheFileContent(fileName):
    """获得文件的内容"""
    fileName = str_strip(fileName)
    fp = open(fileName, 'r') 
    allText = fp.read()
    fp.close()
    return allText


def writeContentToFile(fileName, content, mode='w'):
    """以特定的方式向文件写内容"""
    fileName = str_strip(fileName)
    fp = open(fileName, mode)
    fp.write(content)
    fp.close()
    pass


def substringTheFileName(fileName):
    """文件名长度限制"""
    if len(fileName) > 60:
        fileName = fileName[:60]
    return fileName

def convertChineseToPinyin(chinese):
    """中文转拼音"""
    chinese = str_strip(chinese)
    WORD_DATA_DIR = 'Pinyin/word.data'
    pinyinInstance = pinyin.PinYin(WORD_DATA_DIR)
    pinyinInstance.load_word()
    pinyinName = pinyinInstance.hanzi2pinyin_split(chinese, split="_")

    pinyinName = pinyinName.lower()
    pinyinName = convertQuote(pinyinName)
    return pinyinName

def convertQuote(string):
    """特殊字符转换"""
    quoteList = [
            " ", "\"", "#", "%", "&", "(", ")", ",", "/", ":",
            ";", "<", "=", ">", "?", "@", "\\", "|"
    ]
    for quote in quoteList:
        string = string.replace(quote, "")
    return string



def text_wrap_by(start_str, end_str, text):
    """从字符串内取两个符号之间的内容"""
    start = text.find(start_str)
    if start >= 0:
        start += len(start_str)
        end_str = text.find(end_str, start)
        if end_str >= 0:
            return text[start:end_str].strip()
    pass


def substring(start_str, text):
    """从指定的字符串截取后的子串"""
    m = text.find(start_str)
    subText = text[m+len(start_str):]
    return subText


def str_strip(string):
    """去掉首尾的空格"""
    return string.strip()


def convert_character(string, origin_string, replace_string, max=None):
    """用指定的字符替换文本中指定的字符"""
    if max == None:
        string = string.replace(origin_string, replace_string)
    else:
        string = string.replace(origin_string, replace_string, int(max))
    return string


class HighlightRenderer(mistune.Renderer):
    """markdown转html渲染类"""
    def block_code(self, code, lang):
        if not lang:
            """若markdown中没指定代码块的语言，则默认设为C，否则生成的html没效果"""
            lang = 'C' 
            # return '\n<pre><code>%s</code></pre>\n' % \
        mistune.escape(code)
        lexer = get_lexer_by_name(lang, stripall=True)
        formatter = HtmlFormatter()
        return highlight(code, lexer, formatter)


def transformTheMarkdownToHtml(text):
    """markdown文本转html文本"""
    renderer = HighlightRenderer()
    markdown = mistune.Markdown(renderer=renderer)
    html = ''
    try:
        html = markdown(text)
    except Exception as e:
        LogE(text)
        raise e

    # 由于highlight..js原因，必须有code才行(为了不使用JQuery)
    html = convert_character(html, '<div class="highlight"><pre><span', '<div class="highlight"><pre><code><span')
    html = convert_character(html, '</pre></div>', '</code></pre></div>')
    return html



def converComment(DIR):
    """ 转换注释"""
    DIR = str_strip(DIR)
    array = getAllFileInDir(DIR)
    for path in array:
        # print path
        sufix = os.path.splitext(path)[1][1:]
        sufix = '.' + sufix
        if sufix in TYPE:
            converSentence(path)
            # print sufix
    pass

def converSentence(path):
    """ 转换注释中的哪一段 """
    content = getTheFileContent(path)
    content = convert_character(content, '//  Created by zhouruibin on', '//  Created by Ruibin.Chow on')
    content = convert_character(content, '//  Copyright © 2016年 zruibin. All rights reserved.', '//  Copyright © 2016年 Ruibin.Chow. All rights reserved.')
    writeContentToFile(path, content) 
    LogI(path)
    pass

def generateEpub(name, chapters, outputDir, style):
    LogI(name)
    # print(outputDir)
    # print(" ")
    """
    if not os.path.exists(outputDir):
        os.makedirs(outputDir)

    orderDict = collections.OrderedDict()
    def setOrderDict(key, value):
        if key in orderDict:
            values = orderDict[key]
            values.append(value)
        else:
            orderDict[key] = [value]

    book = epub.EpubBook()
    # 书籍元信息
    book.set_identifier(str(random.seed()))
    book.set_title(name)
    book.set_language("cn")
    book.add_author("Ruibin.Chow")
    book.add_metadata("DC", "description", name)
    commonCSS = epub.EpubItem(uid="style_common",
                            file_name="style/common.css",
                            media_type="text/css",
                            content=style)
    book.add_item(commonCSS)
    for chapter in chapters:
        categoryIndex = chapter[0]
        categoryName = chapter[1]
        xhtml = chapter[2].replace(".html", ".xhtml")
        detail = chapter[2].replace(".html", "")
        htmlContent = chapter[3]
        # print(categoryIndex, categoryName, xhtml)
        title = "{} {}-{}".format(str(categoryIndex), categoryName, detail)
        if len(categoryName) == 0:
            title = "{} {}".format(str(categoryIndex), detail)
        chap = epub.EpubHtml(title=title, file_name=categoryName+"_"+xhtml,
                            lang='cn', content=htmlContent)
        chap.add_item(commonCSS)
        setOrderDict(categoryName, chap)

    #把所有chapters导入book里，并添加目录和书脊
    tocList = []
    chaplist = []
    index = 0
    for categoryName, chaps in orderDict.items():
        sectionName = str(index) + ". " + categoryName
        tocList.append((epub.Section(sectionName), tuple(chaps)))
        for chap in chaps:
            book.add_item(chap)
            chaplist.append(chap)
        index = index + 1

    # define Table Of Contents
    book.toc = tuple(tocList)
    book.spine=chaplist

    # 添加默认的 NCX and Nav file
    book.add_item(epub.EpubNcx())
    book.add_item(epub.EpubNav())
    
    # 保存epub
    bookname = name + ".epub"
    bookPath = os.path.join(outputDir, bookname)
    if os.path.exists(bookPath):
        os.remove(bookPath)
    epub.write_epub(bookPath, book)
    LogI("书本 {} 已导出".format(bookname))
    """
    pass





if __name__ == '__main__':
    # tt = 'Android SDK更新问题'
    # tt = convert_character(tt, ' ', '、')
    # print tt
    # print convertChineseToPinyin(tt)
    # fileList = getAllFileInDir(Macros.MARDDOWN_DIR)
    # for path in fileList:
    #     path = convert_character(path, ' ', '、')
    #     path = os.path.basename(path)[:-3]
    #     # print path
    #     path = convertChineseToPinyin(path)
    #     print path
    #     break
    #     pass

    # s = 'C、C++通用Makefile在.md'
    # print s[:-3]
    # print os.path.basename(Macros.ARTICLE_DIR)

    # tags = transformTheTagKeyToValue([0, 7, 8, 9, 14, 18])
    # for tag in tags:
    #     tag = convertChineseToPinyin(tag)
    #     print tag
    #     pass
    
    fileList = getAllFileInDir(Macros.MARDDOWN_DIR)
    for path in fileList:
        LogI(path)
        text = getTheFileContent(path)
        # print text
        html = transformTheMarkdownToHtml(text)
        LogI(html)
        break
        pass






