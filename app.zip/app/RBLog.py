#! /usr/bin/python3
# coding=utf-8
# 
# RBLog.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/23.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import sys, os.path
import inspect

# __line__ = sys._getframe().f_lineno

def log(tag, string):
    """打印输出，行号仍有问题"""
    frameInfo = inspect.stack()[2]
    fileName = os.path.basename(frameInfo.filename).split(".")[0]
    function = frameInfo.function
    lineno = frameInfo.lineno
    if isinstance(string, list):
        string = ', '.join(string)
        pass

    print("[%s:%s:%s][%s] %s" % (fileName, function, str(lineno), tag, string))
    pass

def LogI(string):
    log("I", string)
    pass

def LogE(string):
    log("E", string)
    pass

def LogW(string):
    log("W", string)
    pass

def LogD(string):
    log("D", string)
    pass

def LogV(string):
    log("V", string)
    pass

if __name__ == '__main__':
    pass




