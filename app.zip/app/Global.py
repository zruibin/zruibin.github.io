#! /usr/bin/env python3
# -*- coding: utf-8 -*- 
#
# Global.py
#
# Created by Ruibin.Chow on 2022/06/27.
# Copyright (c) 2022年 Ruibin.Chow All rights reserved.
# 

"""

"""

import collections

globalArticleDict = collections.OrderedDict()


if __name__ == '__main__':
    pass
