#! /usr/bin/python3
# coding=utf-8
# 
# SiteMap.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2017/01/16.
# Copyright (c) 2017年 Ruibin.Chow All rights reserved.
#

import os, os.path
import Macros, Util, DBManager


def generatorAll():
    robots()
    prepareDBData()
    sitemap()
    baidusitemap()
    pass


def robots():
    fileName = '../robots.txt'
    if os.path.exists(fileName):
        os.remove(fileName)

    articleDir = os.path.basename(Macros.ARTICLE_DIR)
    content = """#robots.txt
User-agent: *
Allow: /
Allow: /""" + articleDir + """/

Disallow: /vendor/
Disallow: /h5/
Disallow: /modules/

Sitemap: """ +Macros.HOST_NAME + """/sitemap.xml
Sitemap: """ +Macros.HOST_NAME + """/baidusitemap.xml"""
    Util.writeContentToFile(fileName, content)
    pass


SITEMAP_ARTICLES = []

def prepareDBData():
    global SITEMAP_ARTICLES
    dbDao = DBManager.DBDao.getinstance()
    SITEMAP_ARTICLES = dbDao.queryArticles()
    # for article in SITEMAP_ARTICLES:
    #     tags = dbDao.queryArticleAllTagsByAtricleId(article[0])
    #     print tags
    pass


def sitemap():
    fileName = '../sitemap.xml'
    if os.path.exists(fileName):
        os.remove(fileName)

    urls = ''
    for article in SITEMAP_ARTICLES:
        pinyin = Util.substringTheFileName(article[5])
        hrefName = Macros.HOST_NAME + '/' + os.path.basename(Macros.ARTICLE_DIR) + '/' + pinyin + '.'+ Macros.POSTFIX
        createTime = '%s' % article[6]
        createTime = Util.convertTimeStampToDate(createTime, '%Y-%m-%dT%H:%M:%S.000Z')
        urls = urls + """
        <url>
            <loc>""" + hrefName +  """</loc>
            <lastmod>""" + createTime +  """</lastmod>
        </url>"""

    content = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">""" + urls + """
</urlset>"""
    Util.writeContentToFile(fileName, content)
    pass


def baidusitemap():
    fileName = '../baidusitemap.xml'
    if os.path.exists(fileName):
        os.remove(fileName)
    urls = ''
    for article in SITEMAP_ARTICLES:
        articleName = article[1][:-3]
        pinyin = Util.substringTheFileName(article[5])
        hrefName = Macros.HOST_NAME + '/' + os.path.basename(Macros.ARTICLE_DIR) + '/' + pinyin + '.'+ Macros.POSTFIX
        createTime = '%s' % article[6]
        createTime = Util.convertTimeStampToDate(createTime, '%Y-%m-%dT%H:%M:%S.000Z')
        
        tags = ''
        dbDao = DBManager.DBDao.getinstance()
        tagList = dbDao.queryArticleAllTagsByAtricleId(article[0])
        for  tag in tagList:
            tags = tags + "<tag>" + tag + "</tag>"
            pass

        urls = urls + """
<url>
    <loc>""" + hrefName +  """</loc>
    <lastmod>""" + createTime +  """</lastmod>
    <data>
        <display>
        <title>""" + articleName + """</title>
        <pubTime>""" + createTime +  """</pubTime>
        """ + tags + """
        </display>
    </data>
</url>"""

    content = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">""" + urls + """
</urlset>"""
    Util.writeContentToFile(fileName, content)
    pass






