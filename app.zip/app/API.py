#! /usr/bin/python3
# coding=utf-8
# 
# API.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2017/05/13.
# Copyright (c) 2017年 Ruibin.Chow All rights reserved.
#

import json
import os, os.path, shutil
import DBManager, Util, Macros
from RBLog import *

API_DIR = "../api/"

def dumpJsonString(data):
    jsonDict = {"code": 0, "data": data}
    return json.dumps(jsonDict)


def checkApiDirectory():
    if os.path.exists(API_DIR):
        shutil.rmtree(API_DIR) # 空目录、有内容的目录都可以删
    if not os.path.exists(API_DIR):
        os.mkdir(API_DIR)

def generateArticleContent(DIR, article):
    """获得文章内容，分从数据库中取或直接读取文件内容文本"""
    content = ''
    if Macros.IS_BACKUP_ARTICLE_CONTENT:
        content = base64.decodestring(article[8])
    else:
        articleName = article[1]
        articleName = Util.str_strip(articleName)
        content = Util.getTheFileContent(Macros.MARDDOWN_DIR + articleName)

    # 去掉头部文件信息
    content = Util.substring(Macros.MARKDOWN_DATA_TITLE_END, content)
    # 将markdown文本转换html的样式
    content  = Util.transformTheMarkdownToHtml(content)
    return content


def generateAll(onlyIndex=False):
    """生成所有API Json"""
    checkApiDirectory()
    generateList(onlyIndex)
    generateAllTags(onlyIndex)
    pass


def generateList(onlyIndex=False):
    """生成文章列表API Json"""
    dbDao = DBManager.DBDao.getinstance()
    articlesList = dbDao.queryArticles()

    tempList = []
    for li in articlesList:
        title = li[1]
        pinyin = Util.substringTheFileName(li[5])
        hrefName = os.path.basename(Macros.ARTICLE_DIR) + '/' + pinyin + '.'+ Macros.POSTFIX
        lineDict = {
                "id": li[0],
                "title": title[:-3],
                "summary": li[4],
                "createTime": li[6],
                "modifiedTime": li[7],
                "href": hrefName
        }
        LogI(("API: " + str(title[:-3])))
        tempList.append(lineDict)
        if not onlyIndex:
            generateArticle(li)

    contentJson = dumpJsonString(tempList)

    path = API_DIR + "index.json"
    Util.writeContentToFile(path, contentJson)
    pass


def generateArticle(article):
    """生成文章内容API Json"""
    content = generateArticleContent(API_DIR, article)
    articleName = article[1]
    dataDict = {
            "id": article[0],
            "title": articleName[:-3],
            "summary": article[4],
            "createTime": article[6],
            "modifiedTime": article[7],
            "content": content
    }
    contentJson = dumpJsonString(dataDict)
    LogI(("API->Content: " + str(articleName[:-3])))

    path = API_DIR + str(article[0]) + ".json"
    Util.writeContentToFile(path, contentJson)
    pass


def generateAllTags(onlyIndex=False):
    """生成所有标签API Json"""
    dbDao = DBManager.DBDao.getinstance()
    existsTags = dbDao.queryAllExistTags()

    tempList = []
    for tagKey in existsTags:
        tagValue = str(tagKey)
        tagValuePinyin = Util.convertChineseToPinyin(tagValue)
        articleArray = dbDao.queryAllArticleByTagId(tagKey)
        path = Macros.TAG_PREFIX + tagValuePinyin
        count = len(articleArray)
        tagDict = {
                "tagId": tagKey,
                "tagTitle": tagValue,
                "count": count,
                "path": path
        }
        tempList.append(tagDict)
        if not onlyIndex:
            generateTag(path, articleArray)
        LogI(("生成tag：%s(%d)" % (tagValue, count)))
        # print tagValue, len(articleArray)
        
    contentJson = dumpJsonString(tempList)

    path = API_DIR + "tags.json"
    Util.writeContentToFile(path, contentJson)
    pass


def generateTag(tagPath, articleArray):
    """生成每个标签API Json""" 
    tempList = []
    for article in articleArray:
        articleId = article[0]
        name = article[1][:-3]
        summary = article[4]
        path = str(articleId) + ".json"
        tempDict = {
                "articleId": articleId,
                "name": name,
                "path": path
        }
        tempList.append(tempDict)

    contentJson = dumpJsonString(tempList)

    path = API_DIR + Util.convertQuote(tagPath) + ".json"
    Util.writeContentToFile(path, contentJson)
    pass




if __name__ == '__main__':
    generateAll()
    
    pass


