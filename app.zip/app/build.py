#! /usr/bin/python3
# coding=utf-8
# 
# build.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/13.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

import datetime
import Util, Macros, GeneratorToDB
import sitemap.SiteMap as SiteMap 
import default.Generator as DefaultGenerator
import API
from RBLog import *


def generateAllMarkdownToDB(DIR):
    """将markdown目录下所有文章的信息入数据库"""
    GeneratorToDB.generateAllMarkdownToDB(DIR)
    pass


if __name__ == '__main__':
    # Util.show(Macros.MARDDOWN_DIR)
    # expire_time = "2015-10-13 13:48"
    # print Util.convertDateToTimeStamp(expire_time)

    begin = datetime.datetime.now()

    generateAllMarkdownToDB(Macros.MARDDOWN_DIR)

    DefaultGenerator.generateAllArticleToHtml(Macros.ARTICLE_DIR)
    DefaultGenerator.generateAllTagsToHtml(Macros.ARTICLE_DIR)
    DefaultGenerator.generateArchivesToHtml(Macros.ARTICLE_DIR)
    DefaultGenerator.generateTheIndexHtml()
    DefaultGenerator.generateTheAboutMeHtml()

    SiteMap.generatorAll()

    API.generateAll(True)
    
    end = datetime.datetime.now()
    LogI(('生成所需时间: %.3f 秒' % (end - begin).seconds))
    pass









