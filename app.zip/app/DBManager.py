#! /usr/bin/python3
# coding=utf-8
# 
# DBManager.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/13.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#


import sqlite3
from RBLog import *

DB_NAME = 'data.db'


class DBHelper(object):
    """docstring for DB"""
    def __init__(self, name=DB_NAME):
        super(DBHelper, self).__init__()
        self.__conn = sqlite3.connect(name)
        #这个就是事务隔离级别，默认是需要自己commit才能修改数据库，置为None则自动每次修改都提交,否则为""
        # self.conn.isolation_level = None

    def __del__(self):
        self.__conn.close()

    def query(self, sql):
        cursor = self.__conn.cursor()
        cursor.execute(sql) 
        data = cursor.fetchall()
        cursor.close()
        return data

    def insert(self, sql):
        cursor = self.__conn.cursor()
        try:
            cursor.execute(sql)
        except Exception as e:
            LogE(sql)
            LogE(e)
            raise e 
        self.__conn.commit()
        cursor.close()
        
    def delete(self, sql):
        cursor = self.__conn.cursor()
        cursor.execute(sql) 
        self.__conn.commit()
        cursor.close()



class DBDao(object):
    """docstring for DBDao"""

    __instance = None

    def __init__(self):
        # print "init"
        super(DBDao, self).__init__()
        self.__dbHelper = DBHelper(DB_NAME)

    @classmethod
    def getinstance(cls):
        """单例模式"""
        if(cls.__instance == None):
            cls.__instance = DBDao()
        return cls.__instance

    def createTable(self):
        """创建表"""
        createList = [
            'CREATE TABLE IF NOT EXISTS article (_id INTEGER PRIMARY KEY, article_name TEXT, path TEXT, is_top INTEGER, summary TEXT, pinyin TEXT, content TEXT)',

            'CREATE TABLE IF NOT EXISTS article_date (article_id INTEGER PRIMARY KEY, create_time TEXT, modified_time TEXT)',
        
            'CREATE TABLE IF NOT EXISTS tag_article (tag_name TEXT, article_id INTEGER, PRIMARY KEY (tag_name, article_id));'
            ]
        for sql in createList:
            self.__dbHelper.insert(sql)
        pass

    def insertArticle(self, array):
        """往文章表插入数据"""
        sql = "INSERT INTO article (_id, article_name, path, is_top, summary, pinyin, content) VALUES(%d, '%s', '%s', %d, '%s', '%s', '%s')" \
                        % (int(array[0]), array[1], array[2], int(array[3]), array[4], array[5], array[6])
        self.__dbHelper.insert(sql)
        pass

    def insertArticleDate(self, array):
        """往文章时间表插入数据"""
        sql = "INSERT INTO article_date (article_id, create_time, modified_time) VALUES('%d', '%s', '%s')" \
                        %(int(array[0]), array[1], array[2])
        self.__dbHelper.insert(sql)
        pass

    def inserTagArticle(self, array):
        """往文章分类表插入数据"""
        sql = "INSERT INTO tag_article (tag_name, article_id) VALUES('%s', %d)" \
                        %(str(array[0]), int(array[1]))
        self.__dbHelper.insert(sql)
        pass

    def queryArticles(self):
        """查询所有的文章，并把置顶的文章放在前面，按创建时间排序"""
        sql = """
            SELECT _id, article_name, path, is_top, summary, pinyin, article_date.create_time, article_date.modified_time, content 
            FROM article LEFT JOIN article_date 
            WHERE _id == article_date.article_id AND is_top==%d
            ORDER BY article_date.create_time DESC
        """
        topSQL = sql % 1
        topData = self.__dbHelper.query(topSQL)
        nornalSQL = sql % 0
        nornalData = self.__dbHelper.query(nornalSQL)
        topData.extend(nornalData)
        return topData

    def queryArticlesDefault(self):
        """查询所有的文章，按创建时间排序"""
        sql = """
            SELECT _id, article_name, path, is_top, summary, pinyin, article_date.create_time,  article_date.modified_time, content 
            FROM article LEFT JOIN article_date 
            WHERE _id == article_date.article_id 
            ORDER BY article_date.create_time DESC
        """
        data = self.__dbHelper.query(sql)
        return data

    def queryArticleDateById(self, article_id):
        """通过文章id查询文章的创建与修改时间"""
        sql = 'SELECT * FROM article_date WHERE article_id=%d' % (int(article_id))
        data = self.__dbHelper.query(sql)
        return data[0]

    def queryAllExistTags(self):
        """查询所已存在的标签"""
        sql = 'SELECT  DISTINCT tag_name FROM tag_article '
        data = self.__dbHelper.query(sql)
        temp = []
        for li in data:
            temp.append(li[0])
        return temp

    def queryArticleAllTagsByAtricleId(self, atricle_id):
        """通过文章id查询该所拥有的标签"""
        sql = 'SELECT  tag_name FROM tag_article WHERE article_id==%d ORDER BY tag_name ASC' % int(atricle_id)
        data = self.__dbHelper.query(sql)
        temp = []
        for li in data:
            temp.append(li[0])
        return temp

    def queryAllArticleByTagId(self, tag_name):
        """通过标签id查询该所拥有的文章"""
        sql = """
            SELECT  _id, article_name, path, is_top, summary, pinyin, article_date.create_time  
            FROM tag_article LEFT JOIN article LEFT JOIN article_date
            WHERE tag_name=='%s' AND tag_article.article_id==article._id AND _id == article_date.article_id
            ORDER BY article_date.create_time DESC
        """ % str(tag_name)
        data = self.__dbHelper.query(sql)
        return data




if __name__ == '__main__':
    dbDao = DBDao.getinstance()
    # dbDao.createTable()
    data = dbDao.queryAllArticleByTagId(1)
    LogV(data)
    LogV(len(data))





