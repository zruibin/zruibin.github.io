#!/usr/bin/env python
# -*- coding:utf-8 -*-

"""
    Author:cleverdeng
    E-mail:clverdeng@gmail.com
"""
"""
MARK:添加中英文混合转换功能 
Change by Ruibin.Chow on 15/10/17.

WARNING:字符串存在空格会出问题，有bug，需预先把字符串的空格去掉才能正常转换
"""

__version__ = '0.9'
__all__ = ["PinYin"]

WORD_DATA_DIR = './word.data'

import os.path


class PinYin(object):
    def __init__(self, dict_file=WORD_DATA_DIR):
        self.__word_dict = {}
        self.__dict_file = dict_file
        """除了中文外其他严格分割转换的，默认不严格"""
        self.isStrictly = False 


    def load_word(self):
        if not os.path.exists(self.__dict_file):
            raise IOError("NotFoundFile")

        with open(self.__dict_file) as f_obj:
            for f_line in f_obj.readlines():
                try:
                    line = f_line.split('    ')
                    self.__word_dict[line[0]] = line[1]
                except:
                    line = f_line.split('   ')
                    self.__word_dict[line[0]] = line[1]


    def hanzi2pinyin(self, string=""):
        result = []
        for char in string:
            key = '%X' % ord(char)
            key = self.__word_dict.get(key, char).split()[0][:-1].lower()

            length = len(key)
            if length == 0:
                key = ('%s' % char)
            
            result.append(key)

        return result


    def hanzi2pinyin_split(self, string="", split=""):
        result = self.hanzi2pinyin(string)

        """除了中文外其他也严格分割转换的"""
        if self.isStrictly:
            if split == "":
                return result
            else:
                return split.join(result)
            
        """不严格分割转换的"""
        array = []
        text = ""
        resultLength = len(result)
        for i in  range(resultLength):
            key = result[i]
            if len(key) == 0:
                continue
            if len(key) == 1: # 不是拼音的则拼接
                text += key
                if i == resultLength-1: 
                    array.append(text)
            else: # 遇到一个拼音则把之前的字母或其它符号放进list里再清空text，再把拼音放里list，再进行下一轮
                array.append(text)
                text = ""
                array.append(key) 

        while '' in array: # 去掉列表中所有的空元素 
            array.remove('')

        if split == "":
            return array
        else:
            return split.join(array)


if __name__ == "__main__":
    test = PinYin()
    test.load_word()
    string = "WebRTC/iOS、C++、定义和区分高级软件开发工程师"
    # test.isStrictly = True

    print("in: %s" % string)
    
    out = str(test.hanzi2pinyin(string=string))
    print(out)
    print("out: %s" % test.hanzi2pinyin_split(string=string, split="_"))
    
    




