#! /usr/bin/python3
# coding=utf-8
# 
# Macros.py
# zruibin.cc
#
# Created by Ruibin.Chow on 2015/10/14.
# Copyright (c) 2015年 Ruibin.Chow All rights reserved.
#

IS_BACKUP_ARTICLE_CONTENT = False

HOST_NAME = "http://private.zruibin.cn"
INDEX_NAME = 'index.html'
POSTFIX = 'html'
PAGE = 'page'
ARCHIVES = 'archives'
TAG_PREFIX = 'tag_'

VENDER_DIR = '/vender'
IMAGE_DIR = VENDER_DIR + '/image/'
CSS_DIR = VENDER_DIR + '/css/'
JS_DIR = VENDER_DIR + '/js/'
FONT_DIR = VENDER_DIR + '/font/'

MARDDOWN_DIR = '../file/'
ARTICLE_DIR = '../article'
ABOUTME_DIR = '../about/'
ARTICLE_IMAGES_DIR_NAME = 'image'


TIME_FORMAT = '%Y-%m-%d %H:%M'


MARKDOWN_DATA_TITLE_BEGIN = '<!--BEGIN_DATA'
MARKDOWN_DATA_TITLE_END = 'END_DATA-->'

MARKDOWN_DATA_CREATE = 'create_date'
MARKDOWN_DATA_MODIFY = 'modify_date'
MARKDOWN_DATA_TOP = 'is_top'
MARKDOWN_DATA_SUMMARY = 'summary'
MARKDOWN_DATA_TAGS = 'tags'


SIZE_OF_ARCHIVES = 100
#一页最多条数
SIZE_OF_PAGES = 50


MARKDOWN_DATA_EXCEPT_FILES = [
    '.DS_Store'
]


if __name__ == '__main__':
    pass
    





